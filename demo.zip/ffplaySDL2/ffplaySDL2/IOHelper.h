#pragma once
#include <iostream>
class IOHelper
{
public:
	IOHelper(void);
	static std::string GetCurrentPath();
	static void AddErrMsg(long lErrType, const std::string& szErr);
	~IOHelper(void);
	static CRITICAL_SECTION g_csA;
};

