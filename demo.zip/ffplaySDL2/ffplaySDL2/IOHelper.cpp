#include "StdAfx.h"
#include "IOHelper.h"
#include  <direct.h>  
#include <fstream>
#include<ctime>
CRITICAL_SECTION IOHelper::g_csA;
IOHelper::IOHelper(void)
{
	 
}


IOHelper::~IOHelper(void)
{
	
}

std::string IOHelper::GetCurrentPath()
{
	char chpath[MAX_PATH];  
	getcwd(chpath, MAX_PATH);
	std::string  g_szCurrentDir = chpath;
	return g_szCurrentDir;
}

void IOHelper::AddErrMsg( long lErrType, const std::string& szErr )
{

	EnterCriticalSection(&g_csA);

	Sleep(1);
	time_t t;
	time(&t);
	struct tm*now = localtime(&t);

	std::string str= "";
	if(lErrType==1)
	{
		str = asctime(now);
	}
	str += szErr;

	std::locale::global(std::locale(""));

	std::string fullPath = GetCurrentPath() ;
	fullPath += "\\ffplaysdl2.log";

	std::ofstream out(fullPath.c_str(), std::ios_base::app/*std::ios::app*/);
	out << /*s_dwProcThreadId*/ str.c_str() << std::endl;
	 LeaveCriticalSection(&g_csA);
}
