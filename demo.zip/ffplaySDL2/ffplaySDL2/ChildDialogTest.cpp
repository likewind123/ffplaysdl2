// ChildDialogTest.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ffplaySDL2.h"
#include "ChildDialogTest.h"
#include "afxdialogex.h"


// CChildDialogTest �Ի���

IMPLEMENT_DYNAMIC(CChildDialogTest, CDialogEx)

CChildDialogTest::CChildDialogTest(CWnd* pParent /*=NULL*/)
	: CDialogEx(CChildDialogTest::IDD, pParent)
{
	nFull = false;
	media = NULL;
}

CChildDialogTest::~CChildDialogTest()
{
}

void CChildDialogTest::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CChildDialogTest, CDialogEx)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
END_MESSAGE_MAP()


// CChildDialogTest ��Ϣ��������


void CChildDialogTest::OnLButtonDown(UINT nFlags, CPoint point)
{
	//
	ptstart = ptend = point;
	bMove = true;
	CDialogEx::OnLButtonDown(nFlags, point);
}

void CChildDialogTest::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	
	media->bStopDraw = true;
	CDialogEx::OnLButtonDblClk(nFlags, point);
	CRect    rect_full;
	//SetDrawStatus(false);
	if(nFull == FALSE)    // nFull = FALSE; ��ǰ����ȫ��
	{                   
		m_pParentWnd = this->GetParent();
		GetWindowRect(m_fullRect);
		GetWindowPlacement(&m_wpmSave);

		ModifyStyle(WS_CHILD,WS_POPUP);
		SetParent(NULL);

		GetDesktopWindow()->GetWindowRect(rect_full);
		MoveWindow(rect_full,TRUE);
		Invalidate(TRUE);   
		nFull = TRUE; 
		
	}
	else                // nFull = TRUE; ��ǰ��ȫ��
	{
		SetParent(m_pParentWnd); // ������������Ϊ�Ի���
		MoveWindow(m_fullRect,TRUE); // ����picture control��λ��
		ModifyStyle(WS_POPUP,WS_CHILD);
		SetWindowPlacement(&m_wpmSave);
		Invalidate(TRUE);
		nFull = FALSE;
	
	}
	media->toggle_full_screen(media->GetIs());
	media->GetIs()->force_refresh = 1;
	//SetDrawStatus(true);
	media->bStopDraw = FALSE;
}

void CChildDialogTest::Open( LPCTSTR sztest )
{
	
}


void CChildDialogTest::OnLButtonUp(UINT nFlags, CPoint point)
{
	// 
	bMove = false;
	ptend = point;
	CDialogEx::OnLButtonUp(nFlags, point);
}


void CChildDialogTest::OnMouseMove(UINT nFlags, CPoint point)
{
	// 
	if (bMove)
	{
		ptend = point;
	}
	CDialogEx::OnMouseMove(nFlags, point);
}


BOOL CChildDialogTest::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: 
	if (zDelta<0)
	{
		//��С
	}
	else
	{
		//�Ŵ�
	}
	return CDialogEx::OnMouseWheel(nFlags, zDelta, pt);
}
