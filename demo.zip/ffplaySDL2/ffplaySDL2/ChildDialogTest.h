#pragma once

#include "Media.h"
// CChildDialogTest �Ի���

class CChildDialogTest : public CDialogEx
{
	DECLARE_DYNAMIC(CChildDialogTest)

public:
	CChildDialogTest(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CChildDialogTest();

// �Ի�������
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	bool nFull ;
	CRect m_fullRect;
	WINDOWPLACEMENT m_wpmSave;
	CPoint ptstart;
	CPoint ptend;
	bool bMove;
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	void Open(LPCTSTR sztest);
	CMedia *media;
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
};
